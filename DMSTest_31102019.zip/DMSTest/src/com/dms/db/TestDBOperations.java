package com.dms.db;

import java.util.Set;

public class TestDBOperations {

	
	public static void main(String arg[]) {

		
		try {
			System.out.println("**** Welcome to DMS Application ****");
			boolean isExport = Boolean.valueOf(JDBCUtil.getProp().getProperty("table.export"));
			if(isExport){
				JDBCUtil.getReadWriteSource().config();
			String tableNames = JDBCUtil.getProp().getProperty("table.names");
				if(tableNames!=null && tableNames.length()>0){
					String tables[] = tableNames.split(",");
					//Generate the xml with data from given table				
					JDBCUtil.getReadWriteSource().databaseToXml(tables);
					System.out.println("Data has been generated in Current folder for the given table(s) with name export.xml");

					System.out.println("**************YOU CAN GIVE MULTIPLE TABLES EACH SEPARATED BY COMMA(,) Ex : Table1,Table2,Table3..  ******************");

				}else{
					System.out.println("You have not given any table names in param.properties file. So, proceeding with all the tables in the schema "+JDBCUtil.getSourceDbSchema());
					String tables [] = JDBCUtil.getReadWriteSource().getAllTablesNames();
					JDBCUtil.getReadWriteSource().databaseToXml(tables);
					System.out.println("Data has been generated in Current folder for the given table(s) with name export.xml");

					System.out.println("**************YOU CAN GIVE MULTIPLE TABLES EACH SEPARATED BY COMMA(,) Ex : Table1,Table2,Table3..  ******************");


				}
			}
			boolean isImport = Boolean.valueOf(JDBCUtil.getProp().getProperty("table.import"));
			
			if(isImport){
				Set<String> tables = JDBCUtil.getReadWriteDest().generatedXmlToDatabase();
				if(tables!=null && tables.size()>0){
					JDBCUtil.getReadWriteDest().createTrigger(tables);
				}else{
					System.out.println("Triggers are available for all tables.");
				}
			}
			
			if(!isExport && !isImport){
				System.out.println("********************** Both Export and imports are disabled.. Nothing to process.So, Returning back *******************");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}


	}

	
	}
