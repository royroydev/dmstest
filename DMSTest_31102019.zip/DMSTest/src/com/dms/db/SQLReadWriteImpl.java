package com.dms.db;


import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class SQLReadWriteImpl implements IReadWrite{

	
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	DOMSource domSource = null;
	
	Element tables = null;
	Document doc = null;
	Map<String,String> existingTables = null;
	
	@Override
	public void config() {

		try{
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			doc = builder.newDocument();
			tables = doc.createElement("Tables");
			doc.appendChild(tables);
			con = JDBCUtil.getSourceDatabaseCon();
			existingTables = new HashMap<String,String>();
		}catch(Exception e){
			System.out.println("Exception during configuration.."+e);
		}
	}
	
	@Override
	public Document databaseToXml(String dbTableNames[]) throws TransformerException,
			ParserConfigurationException, IOException {

		StringBuffer refTables = new StringBuffer("");
			
			try{			
				if(dbTableNames!=null && dbTableNames.length>0){
					for(String dbTableName : dbTableNames){
			pstmt = con
					.prepareStatement("select * from "+dbTableName);

			rs = pstmt.executeQuery();

			ResultSetMetaData rsmd = rs.getMetaData();//to retrieve table name, column name, column type and column precision, etc..
			int colCount = rsmd.getColumnCount();
			

		    DatabaseMetaData meta = con.getMetaData();
		     // The Oracle database stores its table names as Upper-Case,
		     // if you pass a table name in lowercase characters, it will not work.
		     // MySQL database does not care if table name is uppercase/lowercase.
		     //
		    ResultSet rs4Fk = meta.getImportedKeys(null, con.getCatalog(), dbTableName);
		    Map<String,String> refMap = new HashMap<String,String>();
		    Map<String,String> pkMap = new HashMap<String,String>(); 
		    while(rs4Fk.next()){
		       String fkColumnName = rs4Fk.getString("FKCOLUMN_NAME");
		       String fkTableName = rs4Fk.getString("PKTABLE_NAME");
		       String refColumnName = rs4Fk.getString("PKCOLUMN_NAME");
		       refMap.put(fkColumnName, refColumnName+","+fkTableName);
		       
		     }
		    ResultSet rs4Pk =  meta.getPrimaryKeys(null, con.getCatalog(), dbTableName);
		    
		    while(rs4Pk.next()){
			       String pkColumnName = rs4Pk.getString("COLUMN_NAME");
			       
			       pkMap.put(pkColumnName, pkColumnName);
			       
			    }
		    
		    Element table = doc.createElement("Table");
		    tables.appendChild(table);
			
		    Element tableName = doc.createElement("TableName");
			tableName.appendChild(doc.createTextNode(dbTableName));
			table.appendChild(tableName);

			Element structure = doc.createElement("TableStructure");
			table.appendChild(structure);

			Element col = null;
			for (int i = 1; i <= colCount; i++) {

				col = doc.createElement("Column" + i);
				table.appendChild(col);
				
				String curColName = rsmd.getColumnName(i);
				Element columnNode = doc.createElement("ColumnName");
				columnNode
						.appendChild(doc.createTextNode(rsmd.getColumnName(i)));
				col.appendChild(columnNode);

				Element typeNode = doc.createElement("ColumnType");
				typeNode.appendChild(doc.createTextNode(String.valueOf((rsmd
						.getColumnTypeName(i)))));
				col.appendChild(typeNode);

				Element lengthNode = doc.createElement("Length");
				lengthNode.appendChild(doc.createTextNode(String.valueOf((rsmd
						.getPrecision(i)))));
				col.appendChild(lengthNode);
				
				Element requiredNode = doc.createElement("Required");
				requiredNode.appendChild(doc.createTextNode(rsmd.isNullable(i)==0?String.valueOf(Boolean.TRUE):String.valueOf(Boolean.FALSE)));
				col.appendChild(requiredNode);
				
				
				if(pkMap.get(curColName)!=null){
					Element pkNode = doc.createElement("PrimaryKey");
					pkNode.appendChild(doc.createTextNode(String.valueOf((true))));
					col.appendChild(pkNode);
				}
				
				
				boolean isForeignKey  = refMap.get(curColName)!=null;
				
				if(isForeignKey){
					
					String refTableData = refMap.get(curColName);
					
					String values[] = refTableData.split(",");
					
					Element fkNode = doc.createElement("RefKey");
					fkNode.appendChild(doc.createTextNode(values[0]));
					col.appendChild(fkNode);
					
					Element fkTable = doc.createElement("RefTable");
					Text refTab = doc.createTextNode(values[1]);
					fkTable.appendChild(refTab);
					col.appendChild(fkTable);

					String refTabName = refTab.getTextContent();
					if(existingTables.get(refTabName)==null){
						
						refTables.append(refTab.getTextContent() + ",");
						existingTables.put(refTabName, refTabName);
					}

				}
				
				structure.appendChild(col);
			}

			//System.out.println("Column count = " + colCount);

			Element tableRows = doc.createElement("TableData");
			table.appendChild(tableRows);
			if(Boolean.valueOf(JDBCUtil.getProp().getProperty("table.export.rows"))){
				int l = 0;
				while (rs.next()) {
					Element row = doc.createElement(dbTableName + (++l));
					table.appendChild(row);
					for (int i = 1; i <= colCount; i++) {
						String columnName = rsmd.getColumnName(i);
						Object value = rs.getObject(i);
						Element node = doc.createElement(columnName);
						node.appendChild(doc.createTextNode((value != null) ? value
								.toString() : ""));
						row.appendChild(node);
					}
					tableRows.appendChild(row);
				}
			}
			System.out.println("Created Structure of table :"+dbTableName);
					
		}
			
		}
			if(refTables!=null && refTables.length()>0){
				databaseToXml(refTables.toString().split(","));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}		
			doc.getDocumentElement().normalize();
			domSource = new DOMSource(doc);
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer transformer = tf.newTransformer();
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION,
					"yes");
			transformer.setOutputProperty(OutputKeys.METHOD, "xml");
			transformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");

			File generateFile = new File("export.xml");
			if(!generateFile.exists()){
				generateFile.createNewFile();
			}
			StreamResult sr = new StreamResult(generateFile);
			transformer.transform(domSource, sr);

			

		return doc;

	}

	private boolean isTableExist(String tableName) {
		
		PreparedStatement prepStmt = null;
			
			try{
				prepStmt = JDBCUtil.getDestDatbaseCon().prepareStatement("SELECT count(*) FROM information_schema.tables WHERE table_schema = ? AND table_name = ?");
				prepStmt.setString(1, JDBCUtil.getDestDbSchema());
				prepStmt.setString(2, tableName);
				ResultSet rs = prepStmt.executeQuery();
				if(rs.next()){
					long noOfTables = rs.getLong(1);
					if(noOfTables >= 1){
						return true;
					}else{
						return false;
					}
				}
			}catch(SQLSyntaxErrorException e){
				System.out.println(" Exception while creating or altering the table "+e);
				System.out.println(" Continuing for other table creation/alter ");
			}catch(SQLException e){
				e.printStackTrace();
				System.out.println(tableName+" Tabel already exist");
				System.out.println(" Going for Alter table creation/alter ");
			}
		
		
		return false;
	}

	
private boolean isColumnExist(String tableName,String columnName) {
		
		PreparedStatement prepStmt = null;
			
			try{
				prepStmt = JDBCUtil.getDestDatbaseCon().prepareStatement("SELECT count(*) FROM INFORMATION_SCHEMA .COLUMNS WHERE TABLE_SCHEMA =? AND TABLE_NAME =? and column_name = ?");
				prepStmt.setString(1, JDBCUtil.getDestDbSchema());
				prepStmt.setString(2, tableName);
				prepStmt.setString(3, columnName);
				ResultSet rs = prepStmt.executeQuery();
				if(rs.next()){
					long noOfColumns = rs.getLong(1);
					if(noOfColumns == 1){
						return true;
					}else{
						return false;
					}
				}
			}catch(SQLException e){
				System.out.println(" Errot while getting column info "+columnName);
				e.printStackTrace();
			}
		
		
		return false;
	}
	
	@Override
	public String[] getAllTablesNames() {
		String sql = "SELECT table_name FROM information_schema.tables WHERE table_schema=? and table_type = ?";
				
		PreparedStatement prepStmt = null;
		List<String> tableNames = new ArrayList<String>();
		try{
			Connection con = JDBCUtil.getSourceDatabaseCon();
			prepStmt = con.prepareStatement(sql);
			prepStmt.setString(1, JDBCUtil.getSourceDbSchema().toUpperCase());
			prepStmt.setString(2, "BASE TABLE");
			ResultSet rs = prepStmt.executeQuery();
			while(rs.next()){
				tableNames.add(rs.getString(1));
			}
			
		}catch(SQLSyntaxErrorException e){
			System.out.println(" Exception while getting the table names "+e);
		}catch(SQLException e){
			System.out.println(" Exception while getting the table names"+e);
		}
	
	
	return tableNames.size()>0?tableNames.toArray(new String[tableNames.size()]):null;
	}

	@Override
	public Set<String> generatedXmlToDatabase(){
		 try {
			File fXmlFile = new File("import.xml");
			if(!fXmlFile.exists()){
				System.out.println("****** There is no import.xml file found.. So, Assuming nothing to process.. If you want tables to be created/altered then please create the import.xml file and rerun the application ****");
				return null;
			}
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);

			doc.getDocumentElement().normalize();

			Map<String,String> queries = new HashMap<String,String>();
			Set<String> logTables = new HashSet<String>();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

			NodeList tableList = doc.getElementsByTagName("Table");
								
			System.out.println("-------------------------------------------------------");

			for (int table = 0; table < tableList.getLength(); table++) {

				Node tableNode = tableList.item(table);
			if (tableNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) tableNode;
				StringBuffer createQuery = new StringBuffer();
				StringBuffer createLogQuery = new StringBuffer();
				StringBuffer fkey= new StringBuffer();	
				//System.out.println("\nCurrent Element :" + tableNode.getNodeName());
				
				Node tn = eElement.getElementsByTagName("TableName").item(0);
				String tableName = tn.getTextContent();
				//System.out.println("*************** Processing the table "+tableName+" ***************");
				boolean isAlter = false;
				boolean isAlterTableRequired = false;
				boolean isPrimaryKeyAdded = false;
				boolean braceNotAdded = true;
				if(!isTableExist(tableName)){
					System.out.println("Table 	"+getFormatedText(tableName)+" - Not Found and Created  |");
					/** DDL Start*/
					createQuery.append("create ");
					createQuery.append(tableNode.getNodeName());
					
					createQuery.append(" ");
					/**Table Name*/
					createQuery.append(tableName);
				
					createQuery.append("(");
				}else{
					System.out.println("Table 	"+getFormatedText(tableName)+"	- Found   		|");
					/** DDL Start*/
					createQuery.append("alter ");
					createQuery.append(tableNode.getNodeName());
					
					createQuery.append(" ");
					/**Table Name*/
					createQuery.append(tableName);
					isAlter = true;
					
				}
				
				System.out.println("-------------------------------------------------------");

					Node struNode = eElement.getElementsByTagName("TableStructure").item(0);
					
				
					if (tableNode.getNodeType() == Node.ELEMENT_NODE) {
	
						Element strElement = (Element) struNode;
						NodeList colList = strElement.getChildNodes();
						for (int col = 0; col < colList.getLength(); col++) {
							Node colNode = colList.item(col);
							boolean primaryKey = false;
							String colName = null;
							String colType = null;
							String colLength = null;
							String required = null;
						
							String refTab = null;
							String refCol = null;
							if (colNode.getNodeType() == Node.ELEMENT_NODE) {
								Element colElement = (Element) colNode;
								 colName = colElement.getElementsByTagName("ColumnName").item(0).getTextContent();
								 if(isColumnExist(tableName, colName)){
									 System.out.println("Column 	"+getFormatedText(colName)+"	- Found  	       |");
									 continue; 
								 }else{
									 System.out.println("Column 	"+getFormatedText(colName)+"	- Not Found & Added    |");
									 isAlterTableRequired = true;
								 }
								colType = colElement.getElementsByTagName("ColumnType").item(0).getTextContent();
								colLength = colElement.getElementsByTagName("Length").item(0).getTextContent();
								required = colElement.getElementsByTagName("Required").item(0).getTextContent();
							
								refTab = null;
								refCol = null;
								Node pk = colElement.getElementsByTagName("PrimaryKey").item(0);
								if(pk!=null){
									String isPrimaryKey = pk.getTextContent();
									//System.out.println("Is Primary Key : "+isPrimaryKey);
									primaryKey = true;
								}
								
								Node fk = colElement.getElementsByTagName("RefKey").item(0);
								if(fk!=null){
									String foreignKey = fk.getTextContent();
									//System.out.println("Is Foreign Key : "+foreignKey!=null);
									String refTable = colElement.getElementsByTagName("RefTable").item(0).getTextContent();
									refCol = foreignKey;
									refTab = refTable;
									if(refTab==null || "".equals(refTab)){
										System.err.println("**** There is no Reference table found in the import.xml for the column : '"+refCol+"' in table '"+tableName+"' please address this, otherwise table '"+tableName+"' can not be created ****");
									}
								}
								
								if(isAlter){
									createQuery.append(" add ");
								}
								createQuery.append(colName);
								createQuery.append(" ");
								createQuery.append(colType );
								if(Integer.parseInt(colLength) >0 && !colType.equalsIgnoreCase("datetime2") && !colType.equalsIgnoreCase("uniqueidentifier") && !colType.equalsIgnoreCase("TIMESTAMP"))
								{
									createQuery.append("(");
									createQuery.append(colLength);
									createQuery.append(")");
								}
								if(Boolean.valueOf(required)){
									createQuery.append(" not null, ");
								}else{
								
									createQuery.append(" , ");
								}
															
								
								
								

							}
							
							if(Boolean.valueOf(primaryKey)){
								if(!fkey.toString().contains("PRIMARY KEY (")){
									fkey.append(" CONSTRAINT PK_");
									fkey.append(tableName+"_"+colName);
									fkey.append("  PRIMARY KEY (");
									fkey.append(colName);
									fkey.append(")");
								}else{
									fkey = new StringBuffer(fkey.toString().substring(0,fkey.toString().length()-1));
									fkey.append(",");
									fkey.append(colName);
									fkey.append(")");
								}
								
								
								
								isPrimaryKeyAdded = true;
								
								
							}
							
							
							if(refTab!=null){
								if(!isAlter){
									if(fkey.toString().trim().endsWith(",") || !isPrimaryKeyAdded){
										fkey.append("  CONSTRAINT FK_");
									}else{
										fkey.append(" , CONSTRAINT FK_");
									}
									
									fkey.append(colName.length()>3?colName.substring(0,3):colName.length());
									fkey.append("_");
									fkey.append(tableName.length()>3?tableName.substring(0,3):tableName.length());
									fkey.append("_");
									fkey.append(System.currentTimeMillis());
									fkey.append(" FOREIGN KEY (");
								}else{
									fkey.append(" ADD FOREIGN KEY (");
								}
								
								fkey.append(colName);
								fkey.append(")");
								fkey.append(" REFERENCES ");
								fkey.append(refTab);
								fkey.append("(");
								fkey.append(refCol);
								fkey.append(")");
							}
							
							
							
						}
						
						createLogQuery.append(createQuery.toString().replace(tableName, tableName+"_LOG"));
						
						createQuery.append(fkey.toString());
						if(createQuery.toString().trim().endsWith(",")){
							String str = createQuery.toString().substring(0,createQuery.toString().length()-2);
							createQuery = new StringBuffer(str);
						}
						if(!isAlter){
							createQuery.append(")");
						}
						//System.out.println(createQuery);
						System.out.println("-------------------------------------------------------");
						if(createLogQuery.toString().trim().endsWith(",")){
							String str = createLogQuery.toString().substring(0,createLogQuery.toString().length()-2);
							createLogQuery = new StringBuffer(str);
						}
						
						if(!isAlter){
							createLogQuery.append(", OPER CHAR(1) ,AUDIT_USER VARCHAR(100) , AUDIT_DATE DATE ");
							createLogQuery.append(")");
						}
						
						if(isAlterTableRequired){
							queries.put(tableName,createQuery.toString());
							String forLog = createQuery.toString().replace(tableName, tableName+"_LOG");
							queries.put(tableName+"_LOG",forLog);
							//queries.put(tableName+"_DELETE","DROP TRIGGER "+tableName+"_BUD_UPD_DEL");
							logTables.add(tableName+"_LOG");
							
						}
						if(!isAlter && !tableName.toLowerCase().endsWith("_log")){
							queries.put(tableName+"_LOG",createLogQuery.toString());
							//queries.put(tableName+"_BUD",createTrigger(tableName));
							logTables.add(tableName+"_LOG");
						}
						//System.out.println("***************"+tableName+ " Is processed *************");
					}

					//System.out.println(queries);
				NodeList tdList = eElement.getElementsByTagName("TableData");
				for (int tableData = 0; tableData < tdList.getLength(); tableData++) {
					Node colNode = tdList.item(tableData);
					
					// Process table data here
					
				}
				
			}
			
			}
			
			//System.out.println(queries);
			//System.out.println("$$$$$$$$$$$$$$$$$$$ Proceeding with the database changes $$$$$$$$$$$$$$$$$$$");
			if(queries.entrySet().size()>0){
				
				executeQueries(queries,"Table");
				return logTables;
			}else{
				System.out.println("Database is up to date.. No need to create or alter");
				return null;
			}
	    } catch (Exception e) {
		e.printStackTrace();
	    }
		 return null;
	}

	

	private String getFormatedText(String colName) {
		
		int length =20;
		int strLength = colName.length();
		if(strLength>length){
			return colName+" ";
		}else{
			StringBuffer sb = new StringBuffer(colName);
			for(int i =colName.length();i<length;i++){
				sb.append(" ");
			}
			return sb.toString();
		}
				
		
	}

	@Override
	public void createTrigger(Set<String> tableNames) {
		try {
			PreparedStatement pstmt = null;
			Connection con = JDBCUtil.getDestDatbaseCon();
			
			Map<String,String> triggers = new HashMap<String,String>();
			
			for(String table : tableNames){
			List<String> columns = new ArrayList<String>();
			pstmt = con
					.prepareStatement("select * from "+table);

			ResultSet rs = pstmt.executeQuery();

			ResultSetMetaData rsmd = rs.getMetaData();//to retrieve table name, column name, column type and column precision, etc..
			int colCount = rsmd.getColumnCount();
			
			for (int column = 1; column <= colCount; column++) {
				
				String colName = rsmd.getColumnName(column);
				if(!logColumns.contains(colName)){
					columns.add(colName);
				}
				
			}
			columns.addAll(logColumns);
			String originalTable = table.substring(0,table.indexOf("_LOG"));
			/*triggers.put(table+"_DELETE","DROP TRIGGER "+originalTable+"_BUD_UPD_DEL");*/
			String triggerName = originalTable+"_BUD_UPD_DEL";
			if(dropTriggerIfExist(triggerName)){
				triggers.put(originalTable+"_BUD_UPD_DEL",createTrigger(table.toUpperCase(),columns));
			}
			//triggers.put(table+"_DEL",createTrigger(table.toUpperCase(),columns,false));
			}
			
			executeQueries(triggers,"Trigger");
			
			Map<String,String> sequences = new HashMap<String,String>();
			
			for(String table : tableNames){
				String originalTable = table.substring(0,table.indexOf("_LOG"));
				sequences.put(originalTable+"_ID",createSequences(originalTable));
			}

			
			executeQueries(sequences,"Sequence");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//trigger.append(" CREATE OR REPLACE TRIGGER ");
		
		
	}

	private boolean dropTriggerIfExist(String triggerName) {
		
		
		PreparedStatement prepStmt = null;
		Connection con = JDBCUtil.getDestDatbaseCon();
		try{
			prepStmt = con.prepareStatement("SELECT count(*) FROM   sys.triggers WHERE  object_id = OBJECT_ID(?)");
			prepStmt.setString(1, triggerName);
			ResultSet rs = prepStmt.executeQuery();
			if(rs.next()){
				long noOfTables = rs.getLong(1);
				if(noOfTables >= 1){
					prepStmt = con.prepareStatement("DROP Trigger "+triggerName);
					prepStmt.executeUpdate();
				}
			}
		}catch(SQLSyntaxErrorException e){
			
			System.out.println(" Exception while creating or altering the table "+e);
			System.out.println(" Continuing for other table creation/alter ");
			return false;
		}catch(SQLException e){
			e.printStackTrace();
			System.out.println(" Going for Alter table creation/alter ");
			return false;
		}
	
	
	return true;
	}

	private String createSequences(String tableName) {

		StringBuffer trigger = new StringBuffer();
		trigger.append(" CREATE SEQUENCE ");
		trigger.append(tableName);
		trigger.append("_ID ");
		trigger.append("MINVALUE 1  START WITH 1 INCREMENT BY 1 CACHE 20");
		
		return trigger.toString();
		
		
	}
	private String createTrigger(String table, List<String> columns) {
		StringBuffer trigger = new StringBuffer();
		String originalTable = table.substring(0,table.indexOf("_LOG"));
		trigger.append(" CREATE TRIGGER ");
		trigger.append(originalTable);
		trigger.append("_BUD_UPD_DEL  ON ");
		trigger.append(originalTable);
		trigger.append(" AFTER UPDATE , DELETE AS BEGIN SET NOCOUNT ON;");
		trigger.append(" insert into ");
		trigger.append(table);
		trigger.append("(");
		StringBuffer columnNames = new StringBuffer();
		for(String column : columns){
			columnNames.append(column);
			columnNames.append(",");
		}
		trigger.append(columnNames.substring(0,columnNames.length()-1));
		trigger.append(")");
		trigger.append(" SELECT ");
		columnNames = new StringBuffer();
		columnNames.append(" d.");
		for(int c = 0;c<columns.size()-3;c++){
			columnNames.append(columns.get(c));
			columnNames.append(",");
		}
		trigger.append(columnNames);
		trigger.append("CASE WHEN EXISTS(SELECT * FROM INSERTED) THEN 'U' ELSE 'D' END,");	
			
		
		trigger.append(" user, GETDATE() FROM DELETED d ");
		trigger.append(" end"); 
		
		return trigger.toString();
	}
		

	/**
	 * @param queries
	 * @param con
	 * @param isexception
	 * @return
	 * @throws SQLException
	 */
	private boolean executeQueries(Map<String, String> queries,String type)
			throws SQLException {
		boolean isexception = false;
		Statement stmt = null;
		Connection con = JDBCUtil.getDestDatbaseCon();
		Map<String,String> remaining  = new HashMap<String,String>();
		for(Map.Entry query : queries.entrySet()){
				//System.out.println("Creating "+query.getValue().toString());
				stmt = con.createStatement();
				try{
					stmt.execute(query.getValue().toString());
				}catch(Exception e){
					
					if(!type.equals("Sequence") && !type.equals("Trigger")){
						if(!isTableExist(query.getKey().toString())){
							remaining.put(query.getKey().toString(), query.getValue().toString());
						}
					}
					//e.printStackTrace();
					//System.err.println(" Error while creating or altering : "+query.getKey()+", as "+e.getMessage());
					//System.out.println(" Continuing for other table creation/alter ");
					isexception = true;
					continue ;
					
				}
					System.out.println(type+" "+getFormatedText(query.getKey().toString())/*.replace("_Log",""))*/ +"  processed successfully |");
					System.out.println("-------------------------------------------------------");
				
				
			}
		if(remaining.size()>0){
			executeQueries(remaining,type);
		}
		return isexception;
	}

	@Override
	public String[] getAllLogTables() {
		String sql = "SELECT table_name FROM information_schema.tables WHERE table_schema=? and table_type = ? and table_name like '%_Log'";
				
		PreparedStatement prepStmt = null;
		List<String> tableNames = new ArrayList<String>();
		try{
			prepStmt = JDBCUtil.getDestDatbaseCon().prepareStatement(sql);
			prepStmt.setString(1, JDBCUtil.getDestDbSchema());
			prepStmt.setString(2, "BASE TABLE");
			ResultSet rs = prepStmt.executeQuery();
			while(rs.next()){
				tableNames.add(rs.getString(1));
			}
			
		}catch(SQLSyntaxErrorException e){
			System.out.println(" Exception while getting the table names "+e);
		}catch(SQLException e){
			System.out.println(" Exception while getting the table names"+e);
		}
	
	
	return tableNames.size()>0?tableNames.toArray(new String[tableNames.size()]):null;
	}
	
	
	
	
	
	
}
