package com.dms.db;

public enum DataBaseEnum {

	MYSQL("MYSQL"),ORACLE("ORACLE"),SQL("SQL");
	
	String value;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	private DataBaseEnum(String value) {
		this.value = value;
	}
	
	
}
