package com.dms.db;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;

public interface IReadWrite {

	List<String> logColumns = new ArrayList<String>(Arrays.asList("OPER","AUDIT_USER","AUDIT_DATE"));
	public Document databaseToXml(String dbTableNames[]) throws TransformerException,
			ParserConfigurationException, IOException; 

		public String[] getAllTablesNames();
	
	public Set<String> generatedXmlToDatabase();

	
	public void createTrigger(Set<String> tableNames) ;

	public String[] getAllLogTables() ;

	public void config();
	
	
	
	
	
	
}
