package com.dms.db;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

public class TestDBOperations {

	public static void main(String arg[]) {


		//Generate the xml with data from given table 
			try {
				ReadWriteXmltoDB.generateXMLFromTable("Student");
				
			} catch (TransformerException | ParserConfigurationException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	

		//Read the data from XML and create the tables
		try {
			ReadWriteXmltoDB.xmlToTable();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	
	}
