package com.dms.util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class JDBCUtil {
	static Connection mySqlCon = null;
	static Connection oracleCon = null;
	
	
	static{
	
		 try (InputStream input = new FileInputStream("src/param.properties")) {
	            Properties prop = new Properties();
	            // load a properties file
	            prop.load(input);

	            Class.forName(prop.getProperty("mysql.db.driver.class"));
				mySqlCon = DriverManager.getConnection(prop.getProperty("mysql.db.url"),prop.getProperty("mysql.db.user"),prop.getProperty("mysql.db.password"));
				//Class.forName("oracle.jdbc.driver.OracleDriver");
				//oracleCon = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","lavi");
				
				
		 }catch (Exception e) {
			 e.printStackTrace();
		}
	}

	public static Connection getOracleConnection(){
		return oracleCon;
	}
	public static Connection getMySqlConnection(){
		return mySqlCon;
	}
	
	public static void cleanup(Connection con ,Statement ps,ResultSet rs){
		try {
			if(null != con)
				con.close();
			if(null != ps)
				ps.close();
			if(null != rs)
				rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
